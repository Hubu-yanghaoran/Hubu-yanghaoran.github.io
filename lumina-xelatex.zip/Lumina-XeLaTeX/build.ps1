$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    for ($pass = 1; $pass -le 3; $pass++) {
        & xelatex -interaction=nonstopmode -halt-on-error main.tex
        if ($LASTEXITCODE -ne 0) { throw "XeLaTeX failed on pass $pass. See main.log." }
    }
    Write-Host 'Completed: main.pdf'
} finally {
    Pop-Location
}
