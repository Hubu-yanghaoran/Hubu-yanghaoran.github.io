# Lumina XeLaTeX 中文兼容版

这是 Lumina 的独立中文适配副本，不覆盖原版。保留原版渐变封面、配色、页眉页脚、章节装饰、目录与定理框；中文正文使用宋体、中文无衬线使用黑体、中文斜体使用楷体。原有英文和数学字体配置不变，但更换引擎可能造成细微的字体度量与分页差异。

## 环境与编译

推荐完整安装 TeX Live。已经在 Windows / TeX Live 2026 下用 XeLaTeX 连续编译三次，生成 5 页中英文示例，并逐页检查。需要 xeCJK、fontspec、Fandol，以及原版依赖的 tcolorbox、TikZ、Libertine、newtxmath、fontawesome5、gitinfo2 等宏包；完整 TeX Live 通常包含这些依赖。无需依赖 Windows 专有中文字体。

打开 `main.tex`，将编译器明确设为 **XeLaTeX**。在本目录运行：

```powershell
xelatex -interaction=nonstopmode -halt-on-error main.tex
xelatex -interaction=nonstopmode -halt-on-error main.tex
xelatex -interaction=nonstopmode -halt-on-error main.tex
```

也可运行 `build.ps1`，或安装 latexmk 后运行 `latexmk main.tex`。目录和交叉引用需要重复编译。在 Overleaf 上传整个文件夹，选择主文档 main.tex、编译器 XeLaTeX；该云端流程未实际验证。不要选择 pdfLaTeX，也不要只上传 main.tex。

## 文件与布局

- `main.tex`：唯一推荐入口，含课程信息和中英文示例正文。
- `lumina-xecjk.tex`：新增中文适配层，字体与中文图表、目录名称在这里设置。
- `config.tex`：原版配色及课程信息配置。
- `preamble.tex`：原版页面、章节、目录、定理框等样式。
- `title.tex`：原版封面。
- `macros.tex`、`letterfonts.tex`：原版命令与数学字母缩写。
- `images/`：原版图片资源。
- `original-main.tex`、`original-preview.pdf`：未修改的上游英文示例，仅供参考。
- `README.md`、`LICENSE`：保留的上游说明和许可；本说明优先用于中文适配版。
- `main.pdf`：已编译的中文示例。

保持这些文件在同一项目内；不需要引用项目外的文件。原版保留的 article/formal 导言文件并非当前入口，不要随意替换。

## 开始写笔记

在 main.tex 中修改标题、作者、教师、邮箱等 `\renewcommand`，它们覆盖 config.tex 的默认值。正文位于 `\begin{document}` 和 `\end{document}` 之间。保留导言与封面、目录部分，替换示例章节。

```latex
\chapter{线性代数}
\section{向量空间}
中文和 English 可以直接混排。
\dfn[vector-space]{向量空间}{这里写定义。}
\thm[my-theorem]{定理标题}{这里写定理。}
\begin{proof}这里写证明。\end{proof}
\ex[my-example]{例题标题}{这里写例题。}
\nt{这里写备注。}
```

标签应唯一，并使用 ASCII 字母数字及连字符。定义引用可用 `\ref{def:vector-space}`。公式使用 equation、`\label` 和 `\eqref`。图片使用 figure、`\includegraphics` 和 `\caption`。长笔记可拆到 `chapters/topic.tex`，通过 `\input{chapters/topic}` 引入。

## 中文与风格边界

没有改成 ctexbook/report，避免改变原版章节行为。原版 Chapter、Definition、Theorem 等英文装饰标签有意保留；目录、图、表等名称已中文化。中文不具备西文 small caps 字形，因此在原版 small caps 标题中使用普通中文字形。正文中文粗体、楷体和标点已经测试。

如需换系统字体，在 lumina-xecjk.tex 修改 `\setCJKmainfont` 等，但接收者也必须安装相同字体。生僻字可能超出 Fandol 字库，需改用包含这些字的字体。不要直接将原版样式宏包替换成其他模板。

## 已知提醒

本示例没有未解析引用或导致中断的错误。仍有原版字体组合的字体替代警告、small caps 的中文回退、局部 underfull box 提醒及 nullfont 分号提示；逐页检查未发现本示例中文缺字、重叠或裁切。并不表示所有新增内容都无需再次检查。

页脚的 Untracked 来自原版 gitinfo2：没有 Git 元数据时显示默认值，不影响笔记。保留了它以避免改变原版页脚。图片所在第 4 页较空是 LaTeX 浮动页行为，并非内容丢失。内置预览编译器在当前环境不可用；交付 PDF 是本地 XeLaTeX 生成的。
